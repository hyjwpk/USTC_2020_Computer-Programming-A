#include <stdio.h>
#include <time.h>
#include "crossfire.h"

BULLETTYPE Bullet;
LIFETYPE Player[TOTALPLAYER];
DIRECTION Direct[5]={{0,0},{0,-1},{0,1},{-1,0},{1,0}};
int Score;
int Ammo;
char cm,cs;
int SpeedShip;
int SpeedBullet;

int main(){
    int i,playertotal=TOTALPLAYER;
    int supply,quit=0;
    LARGE_INTEGER nFreq,t1,t2;

    srand((unsigned int)time(NULL)*1000);
    InitWin();
    Init();
    supply=0;

    //tick time, receive key
    QueryPerformanceFrequency(&nFreq);
    QueryPerformanceCounter(&t1);
    while (is_run()){
        do {
            if (GetAsyncKeyState('A')&0x8000) cm='A';
            if (GetAsyncKeyState('D')&0x8000) cm='D';
            if (GetAsyncKeyState('W')&0x8000) cm='W';
            if (GetAsyncKeyState('S')&0x8000) cm='S';
            if (GetAsyncKeyState('I')&0x8000) cs='I';
            if (GetAsyncKeyState('J')&0x8000) cs='J';
            if (GetAsyncKeyState('L')&0x8000) cs='L';
            if (GetAsyncKeyState('K')&0x8000) cs='K';
            if (GetAsyncKeyState('Z')&0x8000) {quit=1; break;}
            QueryPerformanceCounter(&t2);
        } while ((t2.QuadPart-t1.QuadPart)*1000.0/(double)nFreq.QuadPart<1000.0/FRAMERATE);
        t1=t2;
        if (quit==1) break;

        //show supply
        supply++;
        if (Ammo>20) supply=0;
        Supply(&supply);

        //bullet fly
        for (i=Bullet.phead; i!=Bullet.ptail; i=(i+1)%BULLETMAX) {
            if (Bullet.owner[i]!=255) BulletFly(i);
        }
        for (; Bullet.phead!=Bullet.ptail; Bullet.phead=(Bullet.phead+1)%BULLETMAX)
            if (Bullet.owner[Bullet.phead]!=255) break;

        //player act
        playertotal=0;
        for (i=0; i<TOTALPLAYER; i++) {
            if (Player[i].lives>0) PlayerAct(i);
            if (Player[i].lives>0) playertotal++;
        }
        Draw();
        if (playertotal==1 && Player[0].lives>0) {
            SpeedShip-=5; SpeedShip=SpeedShip>8 ? SpeedShip : 8;
            SpeedBullet-=1; SpeedBullet=SpeedBullet>3 ? SpeedBullet : 3;
            Score+=1000;
            Restart();
            InitOne(0,Player[0].lives);
            Draw();
            Sleep(1000);
        }
        else if (Player[0].lives==0){
            ShowGameOver();
            while(!(GetAsyncKeyState('C')&0x8000))
                if (GetAsyncKeyState('Z')&0x8000) {quit=1; break;}
            if (quit==1) break;
            GameOver();
            Init();
            supply=0;
        }
    }

    CloseWin();
    return(0);
}
