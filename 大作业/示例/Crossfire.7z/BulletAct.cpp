#include "crossfire.h"

void BulletFly(int no){
    int k,x,y;
    double d;
    if (Bullet.owner[no]==255) return;
    for (d=3;d<GridSize/SpeedBullet;d+=3){
        d=d+3>GridSize/SpeedBullet ? GridSize/SpeedBullet : d+3;
        x=Bullet.posx[no]+Direct[Bullet.direct[no]].x*d;
        y=Bullet.posy[no]+Direct[Bullet.direct[no]].y*d;
        if ((k=hit(x,y,-1,no))!=-1) break;
    }
    if (k==-1) {
        x=Bullet.posx[no]+Direct[Bullet.direct[no]].x*GridSize/SpeedBullet;
        y=Bullet.posy[no]+Direct[Bullet.direct[no]].y*GridSize/SpeedBullet;
        k=hit(x,y,-1,no);
    }
    if (k==-1) {
        Bullet.posx[no]=x;
        Bullet.posy[no]=y;
    }
    else if (k==0 && Bullet.owner[no]!=0) {
        Bullet.owner[no]=255;
        InitOne(0,Player[0].lives-1);
        PlaySound("resources//explosion.wav",NULL,SND_FILENAME|SND_ASYNC);
        Ammo=FULLARMO;
    }
    else if (k>0 && k<100 && Bullet.owner[no]==0) {
        Bullet.owner[no]=255;
        Score+=SCORE(Player[k].lives);
        InitOne(k,Player[k].lives-1);
        PlaySound("resources//explosion.wav",NULL,SND_FILENAME|SND_ASYNC);
    }
    else if (k>=100 && (!Bullet.owner[k-100])!=(!Bullet.owner[no])) {
        Bullet.owner[k-100]=255;
        Bullet.owner[no]=255;
        PlaySound("resources//hit.wav",NULL,SND_FILENAME|SND_ASYNC);
    }
    else {
        Bullet.posx[no]=x;
        Bullet.posy[no]=y;
    }
}

int hit(int x, int y, int pn, int bn){
    int i;
    if (pn!=-1){
        for (i=0;i<TOTALPLAYER;i++) {
            if (i!=pn && Player[i].lives>0 && ABS(x-Player[i].posx)<44 && ABS(y-Player[i].posy)<44) return(i);
        }
        for (i=Bullet.phead; i!=Bullet.ptail; i=(i+1)%BULLETMAX) {
            if (Bullet.owner[i]!=255 && (!Bullet.owner[i])!=(!pn)) {
                if (Bullet.direct[i]<=2 && ABS(x-Bullet.posx[i])<27 && ABS(y-Bullet.posy[i])<34) return(100+i);
                else if (Bullet.direct[i]>=3 && ABS(x-Bullet.posx[i])<34 && ABS(y-Bullet.posy[i])<27) return(100+i);
            }
        }
    }
    else {
        for (i=0;i<TOTALPLAYER;i++) {
            if (Player[i].lives>0 && (!Bullet.owner[bn])!=(!i)) {
                if (Bullet.direct[bn]<=2 && ABS(x-Player[i].posx)<27 && ABS(y-Player[i].posy)<34) return(i);
                else if (Bullet.direct[bn]>=3 && ABS(x-Player[i].posx)<34 && ABS(y-Player[i].posy)<27) return(i);
            }
        }
        for (i=Bullet.phead; i!=Bullet.ptail; i=(i+1)%BULLETMAX) {
            if (i!=bn && Bullet.owner[i]!=255 && (!Bullet.owner[i])!=(!Bullet.owner[bn])) {
                if (Bullet.direct[i]<=2 && Bullet.direct[bn]<=2 && ABS(x-Bullet.posx[i])<5 && ABS(y-Bullet.posy[i])<24) return(100+i);
                else if (Bullet.direct[i]>=3 && Bullet.direct[bn]>=3 && ABS(x-Bullet.posx[i])<24 && ABS(y-Bullet.posy[i])<5) return(100+i);
                else if (ABS(x-Bullet.posx[i])<12 && ABS(y-Bullet.posy[i])<12) return(100+i);
            }
        }

   }
    return(-1);
}
