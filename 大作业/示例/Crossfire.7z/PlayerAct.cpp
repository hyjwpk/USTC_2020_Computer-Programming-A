#include "crossfire.h"

#define RATIO_TURN (rand()&0x7f)<20
#define RATIO_BACK (rand()&0x7f)<2/(FRAMERATE>30?2:1)
#define RATIO_FIRE(x) (rand()&0x7f)<(5+(ENEMYLIVES-x)*0.3)/(FRAMERATE>30?2:1)

void PlayerAct(int no){
    int kx,ky,i;
    double x,y;

    //move
    kx=OnGrid(&Player[no].posx);
    ky=OnGrid(&Player[no].posy);
    if (no==0) {
        switch(cm){
            case 'W': if (kx!=-1) Player[no].direct=1;
                      break;
            case 'S': if (kx!=-1) Player[no].direct=2;
                      break;
            case 'A': if (ky!=-1) Player[no].direct=3;
                      break;
            case 'D': if (ky!=-1) Player[no].direct=4;
        }
    }
    else {
        if ((kx!=-1 && ky!=-1) || Player[no].direct==0){
            if (RATIO_TURN) NewDirect(no,kx,ky);
        }
        else if (RATIO_BACK)
            Player[no].direct=Player[no].direct<=2 ? (3-Player[no].direct)%3 : 7-Player[no].direct;
    }
    CheckGo(no,&x,&y);
    i=hit(x,y,no,-1);
    if (i==-1) {
        Player[no].posx=x;
        Player[no].posy=y;
    }
    else if (no==0)
        if (i>0 && i<100) {
            Score+=SCORE(Player[i].lives);
            InitOne(i,Player[i].lives-1);
            InitOne(0,Player[no].lives-1);
            Ammo=FULLARMO;
            PlaySound("resources//explosion.wav",NULL,SND_FILENAME|SND_ASYNC);
        }
        else if (Bullet.owner[i-100]!=0) {
            InitOne(0,Player[no].lives-1);
            Ammo=FULLARMO;
            Bullet.owner[i-100]=255;
            PlaySound("resources//explosion.wav",NULL,SND_FILENAME|SND_ASYNC);
        }
        else {
            Player[no].posx=x;
            Player[no].posy=y;
        }
    else if (i==0) {
        Score+=SCORE(Player[no].lives);
        InitOne(0,Player[i].lives-1);
        InitOne(no,Player[no].lives-1);
        Ammo=FULLARMO;
        PlaySound("resources//explosion.wav",NULL,SND_FILENAME|SND_ASYNC);
    }
    else if (i>0 && i<100) {
    }
    else if (Bullet.owner[i-100]==0) {
        Score+=SCORE(Player[no].lives);
        InitOne(no,Player[no].lives-1);
        Bullet.owner[i-100]=255;
        PlaySound("resources//explosion.wav",NULL,SND_FILENAME|SND_ASYNC);
    }

    //fire
    if (Player[no].shot>0) {Player[no].shot--; cs=0; return;}
    if ((Bullet.ptail+1)%BULLETMAX==Bullet.phead) {cs=0; return;}
    x=Player[no].posx; y=Player[no].posy;
    kx=OnGrid(&x);
    ky=OnGrid(&y);
    if (no==0) {
        if (Ammo==0) return;
        switch (cs) {
            case 'I': if (kx!=-1) {Bullet.direct[Bullet.ptail]=1; break;}
                      else return;
            case 'K': if (kx!=-1) {Bullet.direct[Bullet.ptail]=2; break;}
                      else return;
            case 'J': if (ky!=-1) {Bullet.direct[Bullet.ptail]=3; break;}
                      else return;
            case 'L': if (ky!=-1) {Bullet.direct[Bullet.ptail]=4; break;}
                      else return;
            default: return;
        }
        cs=0;
        Ammo--;
        PlaySound("resources//fire.wav",NULL,SND_FILENAME|SND_ASYNC);
    }
    else if (RATIO_FIRE(Player[no].lives))
        switch (rand()&0x03) {
            case 0: if (kx>0 && kx<COLS) {Bullet.direct[Bullet.ptail]=1; break;}
                    else return;
            case 1: if (kx>0 && kx<COLS) {Bullet.direct[Bullet.ptail]=2; break;}
                    else return;
            case 2: if (ky>0 && ky<LINES) {Bullet.direct[Bullet.ptail]=3; break;}
                    else return;
            case 3: if (ky>0 && ky<LINES) {Bullet.direct[Bullet.ptail]=4; break;}
                    else return;
        }
    else
        return;
    Player[no].shot=SHOTGAP;
    Bullet.owner[Bullet.ptail]=no;
    Bullet.posx[Bullet.ptail]=Player[no].posx+Direct[Bullet.direct[Bullet.ptail]].x*22;
    Bullet.posy[Bullet.ptail]=Player[no].posy+Direct[Bullet.direct[Bullet.ptail]].y*22;
    Bullet.ptail=(Bullet.ptail+1)%BULLETMAX;
}
