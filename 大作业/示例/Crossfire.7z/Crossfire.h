#include <windows.h>
#include <graphics.h>

#define FRAMERATE 60
#define COLS 7
#define LINES 5
#define TOTALPLAYER 18 //COLS+LINES*2+1
#define BULLETMAX 1000
#define FULLARMO 150
#define SHOTGAP FRAMERATE/6
#define ENEMYLIVES 7
#define MYLIVES 5
#define SCORE(x) (ENEMYLIVES-x+1)*5
#define ABS(x) (x>=0 ? x : -(x))

typedef struct _LIFETYPE{
    int lives;
    double posx,posy;
    double bposx,bposy;
    int direct;
    int shot;
} LIFETYPE;

typedef struct _BULLETTYPE{
    int phead, ptail;
    int owner[BULLETMAX];
    double posx[BULLETMAX],posy[BULLETMAX];
    int direct[BULLETMAX];
} BULLETTYPE;

typedef struct _DIRECTION{
    int x,y;
}DIRECTION;

extern BULLETTYPE Bullet;
extern LIFETYPE Player[TOTALPLAYER];
extern DIRECTION Direct[5];
extern int Score;
extern int Ammo;
extern char cm,cs;
extern int SpeedShip;
extern int SpeedBullet;
extern double GridSize;

extern void InitWin();
extern void CloseWin();
extern void Init();
extern void GameOver();
extern void Restart();
extern void InitOne(int no, char life);
extern void Draw();
extern void ShowGameOver();
extern void Supply(int *supply);
extern int OnGrid(double *x);
extern void NewDirect(int no, int kx, int ky);
extern void CheckGo(int no, double *x, double *y);
extern void PlayerAct(int no);
extern void BulletFly(int no);
extern int hit(int x, int y, int pn, int bn);
