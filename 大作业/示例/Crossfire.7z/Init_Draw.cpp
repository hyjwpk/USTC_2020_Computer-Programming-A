#include "crossfire.h"
#include "stdio.h"

#define BLANK 20
#define BLOCK 100
#define PASSWAY 70

static int ARENAX=BLANK*2+(PASSWAY+BLOCK)*COLS+PASSWAY;
static int ARENAY=BLANK*2+(PASSWAY+BLOCK)*LINES;
static int WINDOWX=ARENAX+220;
static int WINDOWY=ARENAY;
static int hscore;
static PIMAGE imgScreen, imgBackground;
static PIMAGE imgBlock,imgEnemy[7],imgMe,imgBullet[4],imgSupply;
static int supplyflag,supplyx, supplyy;

double GridSize=PASSWAY+BLOCK;

void InitWin(){
    int i,j;
    PIMAGE imgTemp;
    initgraph(WINDOWX,WINDOWY,0);
    setviewport(0,0,WINDOWX,WINDOWY,1);
    setrendermode(RENDER_AUTO);
    setcaption("CrossFire");
    imgBackground=newimage(WINDOWX,WINDOWY);
    imgScreen=newimage(WINDOWX,WINDOWY);
    getimage(imgBlock=newimage(),"resources\\n100-block.png");
    getimage(imgEnemy[0]=newimage(),"resources\\n48-enemy1.png");
    getimage(imgEnemy[1]=newimage(),"resources\\n48-enemy2.png");
    getimage(imgEnemy[2]=newimage(),"resources\\n48-enemy3.png");
    getimage(imgEnemy[3]=newimage(),"resources\\n48-enemy4.png");
    getimage(imgEnemy[4]=newimage(),"resources\\n48-enemy5.png");
    getimage(imgEnemy[5]=newimage(),"resources\\n48-enemy6.png");
    getimage(imgEnemy[6]=newimage(),"resources\\n48-enemy7.png");
    getimage(imgMe=newimage(),"resources\\n48-me.png");
    getimage(imgBullet[0]=newimage(),"resources\\n24-bulletUP.png");
    getimage(imgBullet[1]=newimage(),"resources\\n24-bulletDOWN.png");
    getimage(imgBullet[2]=newimage(),"resources\\n24-bulletLEFT.png");
    getimage(imgBullet[3]=newimage(),"resources\\n24-bulletRIGHT.png");
    getimage(imgSupply=newimage(),"resources\\n32-supply.png");

    //initialize background
    setbkcolor_f(RGB(0xd0,0xd0,0xd0),imgBackground);
    setfillcolor(RGB(0xd0,0xd0,0xd0),imgBackground);
    bar(0,0,WINDOWX,WINDOWY,imgBackground);
    for (i=0;i<LINES;i++)
        for (j=0;j<COLS;j++){
            putimage(imgBackground,BLANK+PASSWAY+j*(PASSWAY+BLOCK),BLANK+PASSWAY+i*(PASSWAY+BLOCK),imgBlock);
        }
   	setcolor(EGERGB(0x0, 0x0, 0xFF),imgBackground);
    setfont(20,0,"Arial",imgBackground);
    setbkmode(TRANSPARENT,imgBackground);
    outtextxy(ARENAX+70,100,"MOVES",imgBackground);
    getimage(imgTemp=newimage(),"resources\\wasd.png");
    putimage_transparent(imgBackground,imgTemp,ARENAX+20,120,EGERGB(0x0,0x0,0x0));
    delimage(imgTemp);
    outtextxy(ARENAX+75,300,"FIRES",imgBackground);
    getimage(imgTemp=newimage(),"resources\\ijkl.png");
    putimage_transparent(imgBackground,imgTemp,ARENAX+20,320,EGERGB(0x0,0x0,0x0));
    delimage(imgTemp);
    outtextxy(ARENAX+55,500,"LIVES  LEFT",imgBackground);
    outtextxy(ARENAX+55,570,"AMMO  LEFT",imgBackground);
    outtextxy(ARENAX+75,640,"SCORE",imgBackground);
    outtextxy(ARENAX+35,710,"HIGHEST  SCORE",imgBackground);
}

void CloseWin(){
    GameOver();
    delimage(imgBlock);
    delimage(imgEnemy[0]);
    delimage(imgEnemy[1]);
    delimage(imgEnemy[2]);
    delimage(imgEnemy[3]);
    delimage(imgEnemy[4]);
    delimage(imgEnemy[5]);
    delimage(imgEnemy[6]);
    delimage(imgMe);
    delimage(imgBullet[0]);
    delimage(imgBullet[1]);
    delimage(imgBullet[2]);
    delimage(imgBullet[3]);
    delimage(imgSupply);
    delimage(imgScreen);
    delimage(imgBackground);
    closegraph();
}

void Init(){
    FILE *fp;
    fp=fopen("score.dat","r+");
    if (fscanf(fp,"%d",&hscore)==0) hscore=0;
    fclose(fp);
    SpeedShip=1.5*FRAMERATE;
    SpeedBullet=0.5*FRAMERATE;
    Ammo=FULLARMO;
    Score=0;
    Restart();
    InitOne(0,MYLIVES);
    supplyflag=supplyx=supplyy=0;
}

void GameOver(){
    FILE *fp;
    fp=fopen("score.dat","w");
    fprintf(fp,"%d",hscore);
    fclose(fp);
}

void Restart(){
    int i;
    cleardevice();
    Sleep(200);
    setbkcolor_f(RGB(0x0,0x0,0x0));
    cleardevice();
    Sleep(200);
    setbkcolor_f(RGB(0xd0,0xd0,0xd0));
    cleardevice();

    Bullet.phead=0;
    Bullet.ptail=0;
    for (i=1; i<TOTALPLAYER; i++) InitOne(i,ENEMYLIVES);
}

void InitOne(int no, char life){
    if (no==0) {
        Player[0].lives=life;
        Player[0].posx=BLANK+(COLS*(BLOCK+PASSWAY)+PASSWAY)/2;
        Player[0].posy=BLANK+(LINES-1)*(BLOCK+PASSWAY)+PASSWAY/2;
        Player[0].direct=0;
        Player[0].shot=0;
        cm=0; cs=0;
    }
    else {
        Player[no].lives=life;
        if (no<=COLS) {
            Player[no].posx=BLANK+(no-1)*(BLOCK+PASSWAY)+PASSWAY+BLOCK/2;
            Player[no].posy=BLANK+PASSWAY/2;
        }
        else if (no<=COLS+LINES) {
            Player[no].posx=BLANK+PASSWAY/2;
            Player[no].posy=BLANK+(no-COLS-1)*(BLOCK+PASSWAY)+PASSWAY+BLOCK/2;
        }
        else {
            Player[no].posx=BLANK+COLS*(BLOCK+PASSWAY)+PASSWAY/2;
            Player[no].posy=BLANK+(no-COLS-LINES-1)*(BLOCK+PASSWAY)+PASSWAY+BLOCK/2;
        }
        Player[no].direct=0;
        Player[no].shot=0;
    }
    Player[no].bposx=Player[no].posx;
    Player[no].bposy=Player[no].posy;
}

void Draw(){
    int i,t,x,y;
    char s[10];
    //initialize Screen
    setbkcolor_f(RGB(0xd0,0xd0,0xd0),imgScreen);
    setfillcolor(RGB(0xd0,0xd0,0xd0),imgScreen);
   	setcolor(EGERGB(0x0, 0x0, 0xFF),imgScreen);
    setfont(20,0,"Arial",imgScreen);
    setbkmode(TRANSPARENT,imgScreen);
    putimage(imgScreen,0,0,imgBackground);
    //show data
    setcolor(EGERGB(0xFF, 0x0, 0x0),imgScreen);
    s[0]=Player[0].lives+'0'; s[1]='\0';
    outtextxy(ARENAX+100,530,s,imgScreen);
    for (t=Ammo, i=2; i>=0; i--, t/=10) s[i]=t%10+'0';
    s[3]='\0';
    outtextxy(ARENAX+93,600,s,imgScreen);
    for (t=Score, i=5; i>=0; i--, t/=10) s[i]=t%10+'0';
    s[6]='\0';
    outtextxy(ARENAX+80,670,s,imgScreen);
    if (Score>hscore) hscore=Score;
    for (t=hscore, i=5; i>=0; i--, t/=10) s[i]=t%10+'0';
    s[6]='\0';
    outtextxy(ARENAX+80,740,s,imgScreen);
    //draw supply
    if (supplyflag==1)
        putimage_transparent(imgScreen,imgSupply,supplyx-16,supplyy-16,EGERGB(0x0,0x0,0x0));
    //draw objects
    for (i=0; i<TOTALPLAYER; i++)
        if (Player[i].lives!=0) {
            x=(int)(Player[i].posx-24+0.5);
            y=(int)(Player[i].posy-24+0.5);
            if (i==0)
                putimage_transparent(imgScreen,imgMe,x,y,EGERGB(0x0,0x0,0x0));
            else
                putimage_transparent(imgScreen,imgEnemy[Player[i].lives-1],x,y,EGERGB(0x0,0x0,0x0));
        }
    for (i=Bullet.phead; i!=Bullet.ptail; i=(i+1)%BULLETMAX)
        if (Bullet.owner[i]!=255) {
            if (Bullet.posx[i]<BLANK || Bullet.posx[i]>=ARENAX-BLANK || Bullet.posy[i]<BLANK || Bullet.posy[i]>=ARENAY-BLANK) {
                Bullet.owner[i]=255;
                continue;
            }
            x=(int)(Bullet.posx[i]-12+0.5);
            y=(int)(Bullet.posy[i]-12+0.5);
            putimage_transparent(imgScreen,imgBullet[Bullet.direct[i]-1],x,y,EGERGB(0x0,0x0,0x0));
        }
    putimage(0,0,imgScreen);
    Sleep(1);
}

void ShowGameOver(){
   	setcolor(EGERGB(0x80, 0x0, 0xFF),imgScreen);
    setfont(60,0,"Arial",imgScreen);
    outtextxy(470,370,"GAMEOVER!!!",imgScreen);
    outtextxy(220,540,"Press 'C' to PLAY AGAIN, 'Z' to QUIT!",imgScreen);
    putimage(0,0,imgScreen);
    Sleep(1);
}

void Supply(int *supply) {
    if (*supply==0) supplyflag=supplyx=supplyy=0;
    else if (*supply==1) {
        supplyflag=1;
        switch (rand()%0x03) {
            case 0: supplyx=BLANK+PASSWAY+BLOCK+PASSWAY+BLOCK/2;
                    supplyy=BLANK+PASSWAY+BLOCK+PASSWAY/2;
                    break;
            case 1: supplyx=BLANK+(COLS-2)*(PASSWAY+BLOCK)+PASSWAY+BLOCK/2;
                    supplyy=BLANK+PASSWAY+BLOCK+PASSWAY/2;
                    break;
            case 2: supplyx=BLANK+PASSWAY+BLOCK+PASSWAY+BLOCK/2;
                    supplyy=BLANK+(LINES-1)*(PASSWAY+BLOCK)+PASSWAY/2;
                    break;
            case 3: supplyx=BLANK+(COLS-2)*(PASSWAY+BLOCK)+PASSWAY+BLOCK/2;
                    supplyy=BLANK+(LINES-1)*(PASSWAY+BLOCK)+PASSWAY/2;
        }
    }
    else if (*supply%(15*FRAMERATE)==0) *supply=0;
    else if (*supply%(10*FRAMERATE)==0) supplyflag=supplyx=supplyy=0;
    else if (*supply%(FRAMERATE/2)==0 && supplyx!=0) supplyflag=1-supplyflag;

    if (ABS(Player[0].posx-supplyx)<GridSize/SpeedShip/2 && ABS(Player[0].posy-supplyy)<GridSize/SpeedShip/2) {
        Score-=FULLARMO-Ammo;
        if (Score<0) Score=0;
        Ammo=FULLARMO;
        *supply=supplyflag=supplyx=supplyy=0;
        PlaySound("resources//reload.wav",NULL,SND_FILENAME|SND_ASYNC);
    }
}

int OnGrid(double *x){
    int k;
    double x1;
    x1=*x-BLANK-PASSWAY/2;
    k=(x1+1)/(PASSWAY+BLOCK);
    x1=x1-k*(PASSWAY+BLOCK);
    if (ABS(x1)<=GridSize/SpeedShip/2) {
        *x=BLANK+PASSWAY/2+k*(PASSWAY+BLOCK);
        return(k);
    }
    else return(-1);
}

void NewDirect(int no, int kx, int ky){
    int i,k=1;
    for (i=1;i<=4;i++) {
        if (i==Player[no].direct) continue;
        switch(i){
            case 1: if (ky>1 && kx!=-1) {Player[no].direct=1; k++;}
                    break;
            case 2: if (ky<LINES-1 && kx!=-1 && rand()%k==0) {Player[no].direct=2; k++;}
                    break;
            case 3: if (kx>1 && ky!=-1 && rand()%k==0) {Player[no].direct=3; k++;}
                    break;
            case 4: if (kx<COLS-1 && ky!=-1 && rand()%k==0) {Player[no].direct=4;}
        }
    }
}

void CheckGo(int no, double *x1, double *y1){
    double x,y;
    *x1=Player[no].posx;
    *y1=Player[no].posy;
    x=*x1+Direct[Player[no].direct].x*GridSize/SpeedShip;
    y=*y1+Direct[Player[no].direct].y*GridSize/SpeedShip;
    OnGrid(&x); OnGrid(&y);
    if (no==0){
        if (x>=BLANK+PASSWAY+BLOCK+PASSWAY/2 && x<=BLANK+(COLS-1)*(PASSWAY+BLOCK)+PASSWAY/2 && \
            y>=BLANK+PASSWAY+BLOCK+PASSWAY/2 && y<=BLANK+(LINES-1)*(PASSWAY+BLOCK)+PASSWAY/2) {
            *x1=x;
            *y1=y;
        }
    }
    else {
        if (*x1>=BLANK+PASSWAY+BLOCK+PASSWAY/2 && *x1<=BLANK+(COLS-1)*(PASSWAY+BLOCK)+PASSWAY/2 && \
            *y1>=BLANK+PASSWAY+BLOCK+PASSWAY/2 && *y1<=BLANK+(LINES-1)*(PASSWAY+BLOCK)+PASSWAY/2) {
            if (x>=BLANK+PASSWAY+BLOCK+PASSWAY/2 && x<=BLANK+(COLS-1)*(PASSWAY+BLOCK)+PASSWAY/2 && \
                y>=BLANK+PASSWAY+BLOCK+PASSWAY/2 && y<=BLANK+(LINES-1)*(PASSWAY+BLOCK)+PASSWAY/2) {
                *x1=x;
                *y1=y;
            }
        }
        else if (((x>=BLANK+PASSWAY/2 && x<=BLANK+PASSWAY+BLOCK+PASSWAY/2) || \
                  (x>=BLANK+(COLS-1)*(PASSWAY+BLOCK)+PASSWAY/2 && x<=BLANK+COLS*(PASSWAY+BLOCK)+PASSWAY/2)) && \
                 (y>=BLANK+PASSWAY+BLOCK/2 && y<=BLANK+(LINES-1)*(PASSWAY+BLOCK)+PASSWAY+BLOCK/2) && \
                 ABS(y-Player[no].bposy)<=BLOCK/2+PASSWAY/2) {
            *x1=x;
            *y1=y;
        }
        else if ((y>=BLANK+PASSWAY/2 && y<=BLANK+PASSWAY+BLOCK+PASSWAY/2) && \
                 (x>=BLANK+PASSWAY+BLOCK/2 && x<=BLANK+(COLS-1)*(PASSWAY+BLOCK)+PASSWAY+BLOCK/2) && \
                 ABS(x-Player[no].bposx)<=BLOCK/2+PASSWAY/2) {
            *x1=x;
            *y1=y;
        }
    }
}
